
version = 1
cloudstream {
    language = "en"
    description = "Xalaflix streaming extension with movies, series, subtitles, and multi-quality playback"
    authors = listOf("YourName")
    iconUrl = "https://xalaflix.io/favicon.ico"
}
